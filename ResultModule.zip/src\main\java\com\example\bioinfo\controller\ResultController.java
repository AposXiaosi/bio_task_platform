package com.example.bioinfo.controller;

import com.example.bioinfo.common.ApiResponse;
import com.example.bioinfo.pojo.AnalysisResult;
import com.example.bioinfo.service.ResultService;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Controller
@RequestMapping("/result")
public class ResultController {

    private final ResultService resultService;

    public ResultController(ResultService resultService) {
        this.resultService = resultService;
    }

    @GetMapping("/tab")
    public String resultTab() {
        return "result-tab";
    }

    @PostMapping("/upload")
    @ResponseBody
    public ApiResponse<AnalysisResult> upload(@RequestParam("taskId") Long taskId,
                                              @RequestParam("file") MultipartFile file) {
        try {
            AnalysisResult result = resultService.uploadResult(taskId, file);
            return ApiResponse.ok("上传成功", result);
        } catch (Exception e) {
            return ApiResponse.fail("上传失败: " + e.getMessage());
        }
    }

    @GetMapping("/list")
    @ResponseBody
    public ApiResponse<List<AnalysisResult>> list(@RequestParam(value = "taskId", required = false) Long taskId) {
        List<AnalysisResult> results = taskId == null
                ? resultService.listAll()
                : resultService.listByTaskId(taskId);
        return ApiResponse.ok("查询成功", results);
    }

    @GetMapping("/download/{id}")
    public ResponseEntity<Resource> download(@PathVariable("id") Long id, HttpServletResponse response)
            throws IOException {
        AnalysisResult result = resultService.getById(id);
        if (result == null) {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            return ResponseEntity.notFound().build();
        }

        Resource resource = new FileSystemResource(result.getFilePath());
        if (!resource.exists()) {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            return ResponseEntity.notFound().build();
        }

        String encodedFileName = URLEncoder.encode(result.getFileName(), StandardCharsets.UTF_8)
                .replaceAll("\\+", "%20");

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename*=UTF-8''" + encodedFileName)
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .contentLength(resource.contentLength())
                .body(resource);
    }
}
