package com.example.bioinfo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.example.bioinfo.mapper")
public class BioinfoPlatformApplication {

    public static void main(String[] args) {
        SpringApplication.run(BioinfoPlatformApplication.class, args);
    }
}
