package com.example.bioinfo.mapper;

import com.example.bioinfo.pojo.AnalysisResult;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ResultMapper {

    int insert(AnalysisResult analysisResult);

    AnalysisResult selectById(@Param("id") Long id);

    List<AnalysisResult> selectByTaskId(@Param("taskId") Long taskId);

    List<AnalysisResult> selectAll();
}
