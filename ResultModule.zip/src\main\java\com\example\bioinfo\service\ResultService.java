package com.example.bioinfo.service;

import com.example.bioinfo.pojo.AnalysisResult;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface ResultService {

    AnalysisResult uploadResult(Long taskId, MultipartFile file) throws IOException;

    AnalysisResult getById(Long id);

    List<AnalysisResult> listAll();

    List<AnalysisResult> listByTaskId(Long taskId);
}
