CREATE TABLE IF NOT EXISTS analysis_result (
    id BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '结果主键',
    task_id BIGINT NOT NULL COMMENT '所属任务ID，和任务模块松耦合关联',
    file_name VARCHAR(255) NOT NULL COMMENT '原始文件名',
    file_path VARCHAR(500) NOT NULL COMMENT '本地存储路径',
    file_size BIGINT NOT NULL COMMENT '文件大小，单位字节',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) COMMENT='分析结果表';
