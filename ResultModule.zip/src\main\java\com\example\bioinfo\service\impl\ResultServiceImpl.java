package com.example.bioinfo.service.impl;

import com.example.bioinfo.mapper.ResultMapper;
import com.example.bioinfo.pojo.AnalysisResult;
import com.example.bioinfo.service.ResultService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@Service
public class ResultServiceImpl implements ResultService {

    private final ResultMapper resultMapper;
    private final String uploadDir;

    public ResultServiceImpl(ResultMapper resultMapper,
                             @Value("${file.upload-dir:uploads}") String uploadDir) {
        this.resultMapper = resultMapper;
        this.uploadDir = uploadDir;
    }

    @Override
    public AnalysisResult uploadResult(Long taskId, MultipartFile file) throws IOException {
        if (taskId == null) {
            throw new IllegalArgumentException("taskId 不能为空");
        }
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("上传文件不能为空");
        }

        String originalFilename = StringUtils.cleanPath(file.getOriginalFilename());
        String storedFileName = buildStoredFileName(originalFilename);
        Path uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();
        Files.createDirectories(uploadPath);

        Path targetFile = uploadPath.resolve(storedFileName);
        try (InputStream inputStream = file.getInputStream()) {
            Files.copy(inputStream, targetFile, StandardCopyOption.REPLACE_EXISTING);
        }

        AnalysisResult analysisResult = new AnalysisResult();
        analysisResult.setTaskId(taskId);
        analysisResult.setFileName(originalFilename);
        analysisResult.setFilePath(targetFile.toString());
        analysisResult.setFileSize(file.getSize());
        analysisResult.setCreateTime(LocalDateTime.now());

        resultMapper.insert(analysisResult);
        return analysisResult;
    }

    @Override
    public AnalysisResult getById(Long id) {
        return resultMapper.selectById(id);
    }

    @Override
    public List<AnalysisResult> listAll() {
        return resultMapper.selectAll();
    }

    @Override
    public List<AnalysisResult> listByTaskId(Long taskId) {
        return resultMapper.selectByTaskId(taskId);
    }

    private String buildStoredFileName(String originalFilename) {
        String extension = "";
        int dotIndex = originalFilename.lastIndexOf(".");
        if (dotIndex >= 0) {
            extension = originalFilename.substring(dotIndex);
        }
        String timePart = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        return timePart + "_" + UUID.randomUUID().toString().replace("-", "") + extension;
    }
}
